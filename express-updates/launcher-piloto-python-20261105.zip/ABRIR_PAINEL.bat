@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PYTHON_CAPTAR=%~dp0_Python\python.exe"
if not exist "%PYTHON_CAPTAR%" goto preparar
"%PYTHON_CAPTAR%" -c "import openpyxl, playwright, PIL, webview, clr, bottle" >nul 2>&1
if not errorlevel 1 goto executar
:preparar
call "%~dp0INSTALAR_DEPENDENCIAS.bat"
if errorlevel 1 (
    mshta "javascript:alert('CAPTAR EXPRESS: nao foi possivel preparar o Python. Consulte o arquivo INSTALACAO_PYTHON.log na pasta do EXPRESS.');close();"
    exit /b 1
)
:executar
"%PYTHON_CAPTAR%" "%~dp0painel.py" 1>>"%~dp0PAINEL_INICIO.log" 2>&1
if errorlevel 1 mshta "javascript:alert('CAPTAR EXPRESS: falha na abertura do painel. Consulte PAINEL_INICIO.log.');close();"
exit /b %errorlevel%
