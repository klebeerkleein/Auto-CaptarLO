# -*- coding: utf-8 -*-
"""Entry-point leve para LAUNCHER. Nao importa nem modifica o motor."""
from pathlib import Path
import subprocess
import sys
import tkinter as tk
from tkinter import messagebox

# .exe gerado com PyInstaller: encontra os arquivos ao lado do EXE.
PASTA = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
SCRIPT = PASTA / 'ABRIR_PAINEL_SEM_CMD.vbs'
if not SCRIPT.is_file():
    janela = tk.Tk()
    janela.withdraw()
    messagebox.showerror('LAUNCHER', 'Nao encontrei ABRIR_PAINEL_SEM_CMD.vbs em:\n' + str(PASTA))
    janela.destroy()
    raise SystemExit(1)

try:
    subprocess.Popen(['wscript.exe', str(SCRIPT)], cwd=str(PASTA),
                     creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
except OSError as exc:
    janela = tk.Tk()
    janela.withdraw()
    messagebox.showerror('LAUNCHER', 'Falha ao abrir painel:\n' + str(exc))
    janela.destroy()
    raise SystemExit(1)
