Option Explicit
Dim shell, fso, pasta, iniciar
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
pasta = fso.GetParentFolderName(WScript.ScriptFullName)
iniciar = fso.BuildPath(pasta, "ABRIR_PAINEL.bat")
If Not fso.FileExists(iniciar) Then
    MsgBox "Arquivo ABRIR_PAINEL.bat nao encontrado na mesma pasta.", vbCritical, "CAPTAR AUTOMATION"
    WScript.Quit 1
End If
shell.CurrentDirectory = pasta
shell.Run Chr(34) & iniciar & Chr(34), 0, False
