@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "DESTINO=%~dp0_Python"
set "PYTHON_CAPTAR=%DESTINO%\python.exe"
set "INSTALADOR=%TEMP%\captar-python-3.13.9-amd64.exe"
set "INSTALADOR_PYTHON=%TEMP%\captar-python-3.13.9-amd64.exe"
set "LOG=%~dp0INSTALACAO_PYTHON.log"
set "VERSAO=3.13.9"
(
 echo ============================================
 echo Preparacao de ambiente CAPTAR EXPRESS
 echo Data: %date% %time%
 echo Instalacao isolada na pasta do EXPRESS
) > "%LOG%"
if not exist "%PYTHON_CAPTAR%" (
    echo Obtendo Python %VERSAO% oficial... >> "%LOG%"
    powershell.exe -NoProfile -NonInteractive -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri 'https://www.python.org/ftp/python/3.13.9/python-3.13.9-amd64.exe' -OutFile $env:INSTALADOR_PYTHON" >>"%LOG%" 2>&1
    if errorlevel 1 goto falha
    powershell.exe -NoProfile -NonInteractive -Command "$s=Get-AuthenticodeSignature -LiteralPath $env:INSTALADOR_PYTHON; if($s.Status -ne 'Valid' -or $s.SignerCertificate.Subject -notmatch 'Python Software Foundation'){exit 1}" >>"%LOG%" 2>&1
    if errorlevel 1 (
        echo Assinatura digital do Python nao validada. >>"%LOG%"
        goto falha
    )
    "%INSTALADOR%" /quiet InstallAllUsers=0 TargetDir="%DESTINO%" PrependPath=0 Include_launcher=0 Include_pip=1 Include_tcltk=1 Include_test=0 Shortcuts=0
    if errorlevel 1 goto falha
    if not exist "%PYTHON_CAPTAR%" goto falha
    del /q "%INSTALADOR%" >nul 2>&1
)
"%PYTHON_CAPTAR%" -m pip --version >>"%LOG%" 2>&1
if errorlevel 1 (
    "%PYTHON_CAPTAR%" -m ensurepip --upgrade >>"%LOG%" 2>&1
    if errorlevel 1 goto falha
)
"%PYTHON_CAPTAR%" -m pip install --disable-pip-version-check openpyxl==3.1.5 playwright==1.64.1 pillow==13.0.0 pywebview==6.2.1 pythonnet==3.2.1 bottle==0.13.4 >>"%LOG%" 2>&1
if errorlevel 1 goto falha
"%PYTHON_CAPTAR%" -c "import openpyxl, playwright, PIL, webview, clr, bottle; print('EXCEL OK')" >>"%LOG%" 2>&1
if errorlevel 1 goto falha
"%PYTHON_CAPTAR%" -m playwright install chromium >>"%LOG%" 2>&1
if errorlevel 1 goto falha
echo SUCESSO: Python e bibliotecas do EXPRESS preparados. >>"%LOG%"
exit /b 0
:falha
echo ERRO: Instalacao nao concluida. Verifique conexao, permissao e LOG. >>"%LOG%"
exit /b 1
